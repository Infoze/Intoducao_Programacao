'''
3. Escreva um programa que lê um número inteiro e informa se o mesmo é par ou ímpar.
'''

numero = int(input('Escolha um valor para um número: '))

if numero % 2 == 0:
    print(f'O número {numero} é par')
else:
    print(f'O número {numero} é ímpar')

#github.com/tiagodefendi
