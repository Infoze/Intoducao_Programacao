'''
12.  Escreva  uma  função  que  recebe  uma  lista  vet  e  devolve  o  maior  e  o  menor  elementos.  Obs:  Não  é
 permitido o uso de mint(), max() e list.sort()
 def find_min_max(vet: list) -> tuple[int, int
'''

def find_min_max(vet:list) ->tuple[int, int]:
    pass

def main():
    print(find_min_max([1,2,56,7,8]))
    print(find_min_max([-13,-14,-13,-56,-67,-86]))

if __name__ == '__main__':
    main()

#github.com/tiagodefendi
