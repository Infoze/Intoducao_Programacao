'''
3. Escreva uma programa que lê dois números inteiros (a e b) e informa:
a. Adição
b. Subtração (a menos b)
'''

numero1 = int(input('Escolha um valor para o 1º número: '))
numero2 = int(input('Escolha um valor para o 2º número: '))

soma = numero1 + numero2
diferenca = numero1 - numero2

print(f'A soma entre {numero1} e {numero2} resulta em {soma}')
print(f'A diferênça entre {numero1} e {numero2} resulta em {diferenca}')

#github.com/tiagodefendi
