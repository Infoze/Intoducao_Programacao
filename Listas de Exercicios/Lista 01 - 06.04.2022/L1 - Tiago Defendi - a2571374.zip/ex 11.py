'''
11. Escreva um programa que lê um valor em radianos e o converte para Radiano.
'''

numeroRadiano = float(input('Escolha um valor em radianos para ser convertido em graus: '))
pi = 3.141593

numeroGrau = numeroRadiano * 180 / pi

print(f'O número {numeroRadiano} radianos é equivalente a {numeroGrau}°')

#github.com/tiagodefendi
