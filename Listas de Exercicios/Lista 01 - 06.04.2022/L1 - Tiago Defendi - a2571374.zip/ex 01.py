'''
1. Escreva um para imprimir o seguinte texto:

 ------------------------
[ PROGRAMANDO EM PYTHON! ]
 ------------------------
'''

print('''
 ------------------------
[ PROGRAMANDO EM PYTHON! ]
 ------------------------
      ''')

#github.com/tiagodefendi
