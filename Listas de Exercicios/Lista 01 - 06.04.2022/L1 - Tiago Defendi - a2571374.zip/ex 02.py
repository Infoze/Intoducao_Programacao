'''
2. Escreva uma programa que lê um número inteiro (a) e informa o mesmo com o sinal invertido
Exemplo:
Entrada: 78 ⇒ Imprime: -78
Entrada: -20 ⇒ Imprime: 20
'''

numero = int(input('Escolha um valor para o número: '))
numeroOposto = numero * -1

print(f'O oposto do número {numero} é {numeroOposto} ')

#github.com/tiagodefendi
